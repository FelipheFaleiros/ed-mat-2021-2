/*
    INSTRUÇÕES

    1) Identifique o algoritmo abaixo.
    2) Faça o mapeamento das variáveis (registre em comentário o propósito de cada uma delas).
    3) Introduza a função de comparação, de modo que o algoritmo possa ser utilizado com vetores de objetos.

*/

const z = (y, x) => {
    let w = 0
    let v = y.length - 1
    while(v >= w) {
        let u = Math.floor((w + v) / 2)
        if(x === y[u]) return u
        else if(x > y[u]) w = u + 1
        else v = u - 1
    }
    return -1
}