/*
    INSTRUÇÕES

    1) Identifique o algoritmo abaixo.
    2) Faça o mapeamento das variáveis (registre em comentário o propósito de cada uma delas).
    3) Introduza a função de comparação, de modo que o algoritmo possa ser utilizado com vetores de objetos.

*/

const z = y => {
    for(let x = 0; x < y.length - 1; x++) {
        let w = x + 1
        for(let i = w + 1; i < y.length; i++) {
            if(y[w] > y[i]) w = i
        }
        if(y[x] > y[w]) {
            [ y[x], y[w] ] = [ y[w], y[x] ]
        }
    }
}